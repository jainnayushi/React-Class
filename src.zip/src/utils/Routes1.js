import React from "react";
import Home from "../components/Home";
import Login from "../auth/Login";
import SignUp from "../auth/SignUp";
import Welcome from "../components/Welcome";
import { Route, Routes } from "react-router-dom";
// import ProtectedRoute from "./ProtectedRoute";

const Routes1 = () => {
  return (
    <Routes>
      <Route path="/" exact element={<Home />} />
      <Route path="/login" exact element={<Login />} />
      <Route path="/register" exact element={<SignUp />} />
      <Route path="/welcome" exact element={<Welcome />} />
      {/* <ProtectedRoute path="/dashboard" exact component={Dashboard} /> */}
    </Routes>
  );
};

export default Routes1;
