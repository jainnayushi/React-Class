import React, { useEffect, useMemo, useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

const ProtectedRoute = ({ children }) => {
  const [loginStatus, setLoginStatus] = useState(false);
  const { login, isLoggedIn } = useAuth();

  console.log("--hhh---", isLoggedIn);

  const component = useMemo(() => {
    console.log(isLoggedIn, "login status");
    return isLoggedIn ? children : <Navigate to="/login" />;
  }, [loginStatus, isLoggedIn]);

  useEffect(() => {
    console.log(isLoggedIn, "islo");
    if (!isLoggedIn) {
      const userEmail = localStorage.getItem("user");
      login(userEmail).then((res) => {
        console.log(res);
        setLoginStatus(res);
      });
    }
  }, [isLoggedIn]);

  console.log(loginStatus, "login status");

  return component;
};

export default ProtectedRoute;
