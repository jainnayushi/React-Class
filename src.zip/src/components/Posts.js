import React from "react";

const Posts = ({ posts }) => {
  return (
    <>
      <div>
        {posts.map((post) => (
          <div key={post.id}>
            <h2>{post.author}</h2>
            <h3>{post.url}</h3>
            <img src={post.download_url} width="100" height="100" />
          </div>
        ))}
      </div>
    </>
  );
};

export default Posts;
