import React from "react";

const Loading = () => {
  return <div style={{ backgroundColor: "red" }}>Loading</div>;
};

export default Loading;
