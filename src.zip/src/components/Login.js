import React, { useCallback, useState } from "react";
import "../Styles/SignUp.css";
import InputField from "./InputField";
import { useAuth } from "../auth/AuthContext";
import { useNavigate } from "react-router-dom";
import { replace } from "formik";

const Login = () => {
  const { login, isLoggedIn } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");

  let validUser = false;
  const handleSubmit = (e) => {
    e.preventDefault();
    login(email).then((res) => {
      res ? navigate("/welcome") : navigate("/");
    });
    // login(email) ? navigate("/welcome") : navigate("/");

    // isLoggedIn ? navigate("/welcome") : navigate("/register");
    // console.log(localStorage.getItem("user"), email, "ddd");
    // localStorage.getItem("user") === email
    //   ? navigate("/welcome")
    //   : navigate("/register");
    // console.log(localStorage.getItem("user") === email);
  };

  // useEffect(() => {
  //   isLoggedIn ? navigate("/welcome") : navigate("/register");
  // }, [isLoggedIn, navigate]);
  return (
    <>
      <div className="container">
        <div className="right">
          <img
            src="https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=dfd2ec5a01006fd8c4d7592a381d3776&auto=format&fit=crop&w=1000&q=80"
            alt=""
          />
        </div>
        <div className="left">
          <div className="header">
            <h1>Welcome {isLoggedIn.toString()} Back! </h1>
            <p>Please login!</p>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="inputfield">
              <label htmlFor={email}>Email</label>
              <input
                label="Email"
                name="email"
                type="email"
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
              />
            </div>
            <InputField label="Password" name="password" type="text" />
            <button type="submit">Login</button>
          </form>
        </div>
      </div>
    </>
  );
};

export default Login;
