import React, { useState } from "react";

const Pagination = ({ postsPerPage, totalPosts, changePage }) => {
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }

  const [activePage, setActivePage] = useState(1);

  return (
    <>
      {/* <nav><ul>
    {pageNumbers.map((number)=>{
        <li key={number}><a onClick={()=>{
            handlePageClick(number);
            changePage(number);
        }}</li>
    })}
    </ul></nav> */}
    </>
  );
};

export default Pagination;
