import React from "react";

const Welcome = () => {
  return (
    <>
      <div className="box-container">
        <div className="box">
          <h1>Welcome Page</h1>
        </div>
      </div>
    </>
  );
};

export default Welcome;
