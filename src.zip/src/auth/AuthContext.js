import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const [user, setUser] = useState([]);

  const addUser = (userEmail) => {
    setUser(userEmail);
  };

  // const login = (email) => {
  //   user === email ? setIsLoggedIn(true) : setIsLoggedIn(false);
  // };

  const login = (email) => {
    const userEmail = localStorage.getItem("user");
    return new Promise((resolve, reject) => {
      if (userEmail === email) {
        console.log("called");
        setIsLoggedIn(true);
        // localStorage.setItem("validUser", true);
        resolve();
      } else {
        setIsLoggedIn(false);
        // localStorage.setItem("validUser", false);
        reject();
      }
    })
      .then(() => {
        return true;
      })
      .catch(() => {
        return false;
      });

    // return false;
    // console.log(localStorage.getItem("user"), email, "ddd");
    // localStorage.getItem("user") === email
    //   ? setIsLoggedIn(true)
    //   : setIsLoggedIn(false);
    // localStorage.getItem("user") === email
    //   ? setIsLoggedIn(true)
    //   : setIsLoggedIn(false);
    // setIsLoggedIn(true);
  };

  return (
    <AuthContext.Provider value={{ isLoggedIn, login, addUser }}>
      {children}
    </AuthContext.Provider>
  );
};
export const useAuth = () => {
  return useContext(AuthContext);
};
export default AuthProvider;
