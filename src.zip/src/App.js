// import Registration from "./Task1/Registration";
// import SignUp from "./Task_Form/SignUp";
// import Login from "./Task_Form/Login";
import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Routes1 from "./util/Routes1";
import AuthProvider from "./auth/AuthContext";
import Home from "./components/Home";
import Login from "./components/Login";
import SignUp from "./components/SignUp";
import Welcome from "./components/Welcome";
import Dashboard from "./components/Dashboard";
import Task2 from "./components/Task2";
import ProtectedRoute from "./utils/ProtectedRoute";
import { useAuth } from "./auth/AuthContext";
import { useEffect } from "react";

function App() {
  // const { login, isLoggedIn } = useAuth();

  // useEffect(() => {
  //   if (!isLoggedIn) {
  //     const userEmail = localStorage.getItem("user");
  //     login(userEmail);
  //   }
  // }, [isLoggedIn]);

  return (
    <>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" exact element={<Home />} />
            <Route path="/login" exact element={<Login />} />
            <Route path="/register" exact element={<SignUp />} />
            <Route path="/task2" exact element={<Task2 />} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/welcome"
              element={
                <ProtectedRoute>
                  <Welcome />
                </ProtectedRoute>
              }
            />
            <Route path="/welcome" exact element={<Welcome />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </>
  );
}

export default App;
